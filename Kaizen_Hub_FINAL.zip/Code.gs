
const SHEET_NAME='KAIZEN REPORT';
function setupSheet(){
 const ss=SpreadsheetApp.getActive(); let sh=ss.getSheetByName(SHEET_NAME);
 if(!sh) sh=ss.insertSheet(SHEET_NAME);
 const h=['No','ID Laporan','Timestamp','Nama','Kelas','Jenis','Lokasi','Kategori','Prioritas','Deskripsi','Usulan Solusi','Status','PIC','Tanggal Mulai','Tanggal Selesai','Tindakan Perbaikan','Hasil','Lama Penyelesaian (Hari)','Poin','Keterangan'];
 sh.getRange(1,1,1,h.length).setValues([h]).setFontWeight('bold'); sh.setFrozenRows(1);
 return 'OK';
}
function doGet(){return out({ok:true,service:'KAIZEN HUB API'});}
function doPost(e){
 try{const d=JSON.parse(e.postData.contents||'{}'); const sh=SpreadsheetApp.getActive().getSheetByName(SHEET_NAME)|| (setupSheet(),SpreadsheetApp.getActive().getSheetByName(SHEET_NAME));
  if(d.action==='submit') return out(submit(sh,d));
  if(d.action==='track') return out(track(sh,d.id));
  if(d.action==='dashboard') return out(dashboard(sh));
  return out({ok:false,error:'Action tidak dikenal'});
 }catch(x){return out({ok:false,error:String(x)})}
}
function submit(sh,d){
 const id='KZN-'+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy')+'-'+Utilities.formatString('%04d',sh.getLastRow());
 sh.appendRow([sh.getLastRow(),id,new Date(),d.name||'',d.kelas||'',d.jenis||'Laporan Masalah',d.lokasi||'',d.kategori||'',d.prioritas||'',d.deskripsi||'',d.solusi||'','OPEN','','','','','','',1,'']);
 return {ok:true,id,status:'OPEN'};
}
function track(sh,id){
 const a=sh.getDataRange().getValues();
 for(let i=1;i<a.length;i++)if(String(a[i][1]).trim()===String(id).trim())return {ok:true,id:a[i][1],timestamp:a[i][2],name:a[i][3],kelas:a[i][4],jenis:a[i][5],lokasi:a[i][6],kategori:a[i][7],prioritas:a[i][8],deskripsi:a[i][9],solusi:a[i][10],status:a[i][11],pic:a[i][12],mulai:a[i][13],selesai:a[i][14],tindakan:a[i][15],hasil:a[i][16],lama:a[i][17],poin:a[i][18],keterangan:a[i][19]};
 return {ok:false,error:'Nomor laporan tidak ditemukan'};
}
function dashboard(sh){
 const a=sh.getDataRange().getValues().slice(1).filter(r=>r[1]);
 const total=a.length,open=a.filter(r=>r[11]==='OPEN').length,progress=a.filter(r=>r[11]==='ON PROGRESS').length,done=a.filter(r=>r[11]==='DONE').length;
 const cats={};a.forEach(r=>{if(r[7])cats[r[7]]=(cats[r[7]]||0)+1});
 return {ok:true,total,open,progress,done,completionRate:total?done/total:0,totalPoints:a.reduce((s,r)=>s+(Number(r[18])||0),0),categories:cats};
}
function out(x){return ContentService.createTextOutput(JSON.stringify(x)).setMimeType(ContentService.MimeType.JSON)}
